import SwiftUI
import UserNotifications

struct ContentView: View {
    @AppStorage("autoAttack") private var autoAttack = false
    @AppStorage("autoLoot") private var autoLoot = false
    @AppStorage("monitorHP") private var monitorHP = false
    @AppStorage("monitorMP") private var monitorMP = false
    @AppStorage("hpThreshold") private var hpThreshold = 30.0
    @AppStorage("mpThreshold") private var mpThreshold = 20.0
    @State private var running = false
    @State private var elapsed = 0
    @State private var timer: Timer?
    @State private var status = "Đang chờ khởi động"

    private var timeText: String {
        String(format: "%02d:%02d:%02d", elapsed / 3600, (elapsed / 60) % 60, elapsed % 60)
    }

    var body: some View {
        ZStack {
            Color(red: 0.055, green: 0.06, blue: 0.075).ignoresSafeArea()
            ScrollView {
                VStack(spacing: 16) {
                    VStack(spacing: 5) {
                        Text("HSA TOOL")
                            .font(.system(size: 30, weight: .black, design: .rounded))
                            .foregroundStyle(.red)
                        Text("BẢNG ĐIỀU KHIỂN")
                            .font(.caption.weight(.semibold))
                            .tracking(2)
                            .foregroundStyle(.white.opacity(0.55))
                    }
                    .padding(.top, 22)

                    VStack(alignment: .leading, spacing: 10) {
                        Label("TỰ ĐỘNG HÓA (CÔNG TẮC TRẠNG THÁI)", systemImage: "gamecontroller.fill")
                            .font(.headline)
                            .foregroundStyle(.white)
                        ToggleRow(title: "Auto đánh", subtitle: "Chỉ lưu trạng thái; không tự chạm vào game", isOn: $autoAttack)
                        Divider().overlay(.white.opacity(0.12))
                        ToggleRow(title: "Auto nhặt", subtitle: "Chỉ lưu trạng thái; không tự nhặt đồ", isOn: $autoLoot)
                    }
                    .panel()

                    VStack(alignment: .leading, spacing: 12) {
                        Label("THEO DÕI HP / MP", systemImage: "heart.text.square.fill")
                            .font(.headline)
                            .foregroundStyle(.white)
                        ToggleRow(title: "Nhắc kiểm tra HP", subtitle: "Ngưỡng nhắc: \(Int(hpThreshold))%", isOn: $monitorHP)
                        Slider(value: $hpThreshold, in: 5...90, step: 5)
                            .tint(.red)
                            .disabled(!monitorHP)
                        Divider().overlay(.white.opacity(0.12))
                        ToggleRow(title: "Nhắc kiểm tra MP", subtitle: "Ngưỡng nhắc: \(Int(mpThreshold))%", isOn: $monitorMP)
                        Slider(value: $mpThreshold, in: 5...90, step: 5)
                            .tint(.blue)
                            .disabled(!monitorMP)
                        Text("Ứng dụng không đọc được HP/MP bên trong trò chơi. Các ngưỡng chỉ dùng làm cấu hình nhắc thủ công.")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.55))
                    }
                    .panel()

                    VStack(alignment: .leading, spacing: 10) {
                        Label("PHIÊN SỬ DỤNG", systemImage: "timer")
                            .font(.headline)
                            .foregroundStyle(.white)
                        Text(timeText)
                            .font(.system(size: 34, weight: .bold, design: .monospaced))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                        Text(status)
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.65))
                            .frame(maxWidth: .infinity)
                        HStack(spacing: 10) {
                            Button(action: start) {
                                Label("START", systemImage: "play.fill")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ActionButton(color: .green))
                            Button(action: stop) {
                                Label("STOP ALL", systemImage: "stop.fill")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ActionButton(color: .red))
                        }
                    }
                    .panel()

                    Button {
                        requestNotifications()
                    } label: {
                        Label("Cho phép thông báo nhắc nhở", systemImage: "bell.badge")
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(ActionButton(color: .gray))

                    Text("Lưu ý: HSA TOOL là bảng điều khiển độc lập. iOS không cho ứng dụng này tự điều khiển game khác hoặc tiếp tục tự đánh khi khóa màn hình.")
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.55))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 8)
                        .padding(.bottom, 24)
                }
                .padding(.horizontal, 16)
            }
        }
        .preferredColorScheme(.dark)
        .onDisappear { timer?.invalidate() }
    }

    private func start() {
        guard !running else { return }
        running = true
        status = "Đang chạy bộ đếm trong ứng dụng"
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            elapsed += 1
        }
        if monitorHP || monitorMP {
            scheduleReminder()
        }
    }

    private func stop() {
        running = false
        timer?.invalidate()
        timer = nil
        status = "Đã dừng"
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["hsa-reminder"])
    }

    private func requestNotifications() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
            DispatchQueue.main.async {
                status = granted ? "Đã cho phép thông báo" : "Chưa cấp quyền thông báo"
            }
        }
    }

    private func scheduleReminder() {
        let content = UNMutableNotificationContent()
        content.title = "HSA TOOL"
        content.body = "Đến giờ kiểm tra HP/MP trong trò chơi."
        content.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 15 * 60, repeats: true)
        let request = UNNotificationRequest(identifier: "hsa-reminder", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }
}

private struct ToggleRow: View {
    let title: String
    let subtitle: String
    @Binding var isOn: Bool

    var body: some View {
        Toggle(isOn: $isOn) {
            VStack(alignment: .leading, spacing: 3) {
                Text(title).foregroundStyle(.white).font(.body.weight(.semibold))
                Text(subtitle).foregroundStyle(.white.opacity(0.5)).font(.caption)
            }
        }
        .tint(.green)
    }
}

private struct PanelModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(16)
            .background(Color.white.opacity(0.07))
            .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

private extension View {
    func panel() -> some View { modifier(PanelModifier()) }
}

private struct ActionButton: ButtonStyle {
    let color: Color
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundStyle(.white)
            .padding(.vertical, 14)
            .background(color.opacity(configuration.isPressed ? 0.65 : 0.9))
            .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
