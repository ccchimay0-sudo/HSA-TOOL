import SwiftUI

@main
struct HSAToolApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
