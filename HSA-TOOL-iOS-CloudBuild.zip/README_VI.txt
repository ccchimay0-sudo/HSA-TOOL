HSA TOOL - DU AN IPA iOS

Đây là dự án SwiftUI + workflow GitHub Actions dùng máy macOS trên cloud để build.
Chưa phải file IPA đã build/ký.

CÁCH BUILD BẰNG IPHONE:
1. Tải và giải nén ZIP.
2. Tạo repository GitHub mới (Private được) trong Safari.
3. Upload toàn bộ nội dung thư mục dự án lên repository, giữ nguyên đường dẫn:
   - HSATool.xcodeproj/project.pbxproj
   - HSATool/...
   - .github/workflows/build.yml
4. Mở tab Actions của repository.
5. Chọn "Build HSA TOOL IPA (unsigned)".
6. Nhấn "Run workflow".
7. Khi chạy xong, vào workflow run và tải artifact "HSA-TOOL-unsigned-IPA".
8. Dùng ESign để ký IPA theo quy trình ký ứng dụng thông thường.

LƯU Ý:
- Build workflow tạo IPA chưa ký. ESign có thể không nhận mọi IPA hoặc cấu hình.
  Nếu báo lỗi, cần xem chính xác thông báo; không có bảo đảm cài được trên mọi iOS.
- Thay bundle identifier nếu cần một ID riêng.
- Đây là bảng điều khiển độc lập: Auto đánh/nhặt chỉ là công tắc trạng thái.
  Ứng dụng không điều khiển game khác, không đọc HP/MP trong game, không treo khi khóa màn hình.
- Không đưa chứng chỉ ký, private key, mật khẩu Apple ID hay provisioning profile lên GitHub.
